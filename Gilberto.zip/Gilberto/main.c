#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <stdbool.h>
#include <windows.h>

#include "People.h"
#include "Input.h"

typedef struct
{
    People **peoples;
    int quantity;
} Peoples;

void initPeoples(Peoples *peoples);
void destroyPeoples(Peoples *peoples);
void clearScrn();

int main(void)
{
    setlocale(LC_ALL, "Portuguese");
    Peoples peoples;
    initPeoples(&peoples);

    bool isRunning = true;

    do
    {
        Buffer *buffer = createBuffer(256);
        printf("-----------------------\n");
        printf("1 - limpar tela\n");
        printf("2 - criar conta\n");
        printf("-----------------------\n");
        printf("digite 0 para sair: ");
        ReadBufferKey(buffer);

        int op = atoi(GetToBuffer(buffer));

        switch (op)
        {
        case 0:
            isRunning = false;
            break;
        case 1:
            clearScrn();
            break;

        default:
            printf("\nOpção inválida!\n");
            break;
        }

        freeBuffer(buffer);
    } while (isRunning);

    destroyPeoples(&peoples);
    return 0;
}

void initPeoples(Peoples *peoples)
{
    peoples->quantity = 0;
    peoples->peoples = (People **)malloc(sizeof(People *) * peoples->quantity);

    int i;
    for (i = 0; i < peoples->quantity; i++)
    {
        *(peoples->peoples + i) = NULL;
    }
}

void destroyPeoples(Peoples *peoples)
{
    for (int i = 0; i < peoples->quantity; i++)
    {
        if (peoples->peoples[i] != NULL)
            freePeople(peoples->peoples[i]);
    }

    free(peoples->peoples);
    peoples->peoples = NULL;
    peoples->quantity = 0;
}

void clearScrn()
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    if (hConsole == INVALID_HANDLE_VALUE)
        return;

    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD count, cellCount;
    COORD homeCoords = {0, 0};

    if (!GetConsoleScreenBufferInfo(hConsole, &csbi))
        return;
    
    cellCount = csbi.dwSize.X * csbi.dwSize.Y;

    FillConsoleOutputCharacter(hConsole, (TCHAR)' ', cellCount, homeCoords, &count);

    FillConsoleOutputAttribute(hConsole, csbi.wAttributes, cellCount, homeCoords, &count);

    SetConsoleCursorPosition(hConsole, homeCoords);
}