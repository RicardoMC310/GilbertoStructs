#ifndef PEOPLE_H
#define PEOPLE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    char *name;
    char *password;
    double saldo;
} People;

People *createPeople(const char *name, const char *password, double saldo)
{
    People *people = (People *)malloc(sizeof(People));

    int sizeName = strlen(name) + 1;
    int count = 0;

    people->name = (char *)malloc(sizeof(sizeName));
    while (count < sizeName)
    {
        *(people->name + count) = *(name + count);
        count++;
    }
    *(people->name + count) = '\0';

    count = 0;

    int sizePassword = strlen(password) + 1;

    people->password = (char *)malloc(sizeof(sizePassword));
    while (count < sizePassword)
    {
        *(people->password + count) = *(password + count);
        count++;
    }
    *(people->password + count) = '\0';

    people->saldo = saldo;

    return people;
}

void freePeople(People *people)
{
    if (people == NULL)
        return;

    if (people->name)
    {
        free((void *)people->name);
        people->name = NULL;
    }
    if (people->password)
    {
        free((void *)people->password);
        people->password = NULL;
    }

    free(people);
    people = NULL;
}

#endif // PEOPLE_h