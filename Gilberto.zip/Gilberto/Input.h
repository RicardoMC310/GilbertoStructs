#ifndef INPUT_H
#define INPUT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    char *buffer;
    int size;
} Buffer;

Buffer *createBuffer(int size)
{
    Buffer *buffer = (Buffer *)malloc(sizeof(Buffer));

    buffer->buffer = (char *)malloc(size + 1);
    buffer->size = size + 1;

    return buffer;
}

void ReadBufferKey(Buffer *buffer)
{
    int count = 0;
    while(count < buffer->size)
    {
        int ch = getchar();

        if (ch == '\n' || ch == EOF) break;
        *(buffer->buffer + count++) = (char)ch;
    }

    *(buffer->buffer + count) = '\0';
}

char *GetToBuffer(Buffer *buffer)
{
    return buffer->buffer;
}

void freeBuffer(Buffer *buffer)
{
    if (buffer == NULL) return;
    
    if (buffer->buffer) 
    {
        free((void *)buffer->buffer);
        buffer->buffer = NULL;
    }

    free((void *)buffer);
    buffer = NULL;
}

#endif // INPUT_H