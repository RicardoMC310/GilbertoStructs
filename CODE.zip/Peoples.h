#ifndef PEOPLES_H
#define PEOPLES_H

#include "People.h"

typedef struct
{
    People **peoples;
    int quantity;
    int capacity;
} Peoples;

void InitPeoples(Peoples *peoples)
{
    peoples->quantity = 0;
    peoples->capacity = 5;
    peoples->peoples = (People **)malloc(sizeof(People *) * peoples->capacity);

    int i;
    for (i = 0; i < peoples->quantity; i++)
    {
        *(peoples->peoples + i) = NULL;
    }
}

void FreePeoples(Peoples *peoples)
{
    if (!peoples)
        return;
    for (int i = 0; i < peoples->quantity; i++)
    {
        if (peoples->peoples[i] == NULL)
            continue;
        FreePeople(peoples->peoples[i]);
        peoples->peoples[i] = NULL;
    }
    if (peoples->peoples)
    {
        free(peoples->peoples);
        peoples->peoples = NULL;
    }
    peoples->quantity = 0;
    peoples->capacity = 0;
}

int FindPeopleIndexName(Peoples *peoples, char *name)
{
    for (int i = 0; i < peoples->quantity; i++)
    {
        if (strcmp(peoples->peoples[i]->name, name) == 0)
            return i;
    }
    return -1;
}

void RemovePeople(Peoples *peoples, char *name)
{
    int idx = FindPeopleIndexName(peoples, name);
    if (idx == -1)
    {
        printf(RED "Conta não encontrada!\n" RESET);
        printf("Pressione Enter para continuar...");
        getchar();
        return;
    }

    free((void *)peoples->peoples[idx]);

    for (int i = idx; i < peoples->quantity - 1; i++)
    {
        peoples->peoples[i] = peoples->peoples[i + 1];
    }

    peoples->quantity--;
}

void ReallocPeoples(Peoples *peoples)
{
    peoples->capacity = peoples->capacity == 0 ? 5 : peoples->capacity * 2;
    peoples->peoples = (People **)realloc(peoples->peoples, sizeof(People *) * peoples->capacity);
}

void SavePeoples(Peoples *peoples, const char *filename)
{
    FILE *file = fopen(filename, "wb");
    if (!file)
        return;

    fwrite(&peoples->quantity, sizeof(int), 1, file);
    fwrite(&peoples->capacity, sizeof(int), 1, file);

    int i;
    for (i = 0; i < peoples->quantity; i++)
    {
        SavePeople(*(peoples->peoples + i), file);
    }

    fclose(file);
}

Peoples LoadPeoples(const char *filename)
{
    Peoples peoples;

    FILE *file = fopen(filename, "rb");
    if (!file)
    {
        InitPeoples(&peoples);
        return peoples;
    }

    fread(&peoples.quantity, sizeof(int), 1, file);
    fread(&peoples.capacity, sizeof(int), 1, file);

    if (peoples.quantity <= peoples.capacity)
    {
        peoples.capacity = peoples.quantity == 0 ? 5 : peoples.quantity;
    }

    peoples.peoples = (People **)malloc(sizeof(People *) * peoples.capacity);

    int i;
    for (i = 0; i < peoples.quantity; i++)
    {
        *(peoples.peoples + i) = LoadPeople(file);
    }

    fclose(file);
    return peoples;
}

void RegisterPeople(Peoples *peoples, char *name, char *password)
{
    int i;
    for (i = 0; i < peoples->quantity; i++)
    {
        if (strcmp(peoples->peoples[i]->name, name) == 0)
        {
            printf(RED "Conta já criada!\n" RESET);
            return;
        }
    }

    People *people = CreatePeople(name, password, 100.0);

    if (peoples->quantity >= peoples->capacity)
    {
        ReallocPeoples(peoples);
    }

    peoples->peoples[peoples->quantity++] = people;
}

People *GetPeopleByName(Peoples *peoples, char *name)
{
    int i;
    for (i = 0; i < peoples->quantity; i++)
    {
        if (strcmp(peoples->peoples[i]->name, name) == 0)
        {
            return peoples->peoples[i];
        }
    }

    return NULL;
}

#endif // PEOPLES_H