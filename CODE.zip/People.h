#ifndef PEOPLE_H
#define PEOPLE_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

typedef struct
{
    char **data;
    int quantity;
    int capacity;
} History;

typedef struct
{
    char *name;
    char *password;
    double saldo;
    History history;
} People;

People *CreatePeople(char *name, char *password, double saldo)
{
    People *people = (People *)malloc(sizeof(People));
    if (!people)
        return NULL;

    size_t name_len = strlen(name) + 1;
    people->name = (char *)malloc(name_len);
    if (!people->name)
    {
        free(people);
        return NULL;
    }
    memcpy(people->name, name, name_len); // copia incluindo '\0'

    size_t pass_len = strlen(password) + 1;
    people->password = (char *)malloc(pass_len);
    if (!people->password)
    {
        free(people->name);
        free(people);
        return NULL;
    }
    memcpy(people->password, password, pass_len);

    people->saldo = saldo;

    people->history.capacity = 5;
    people->history.quantity = 0;
    people->history.data = (char **)malloc(sizeof(char *) * people->history.capacity);
    if (!people->history.data)
    {
        free(people->password);
        free(people->name);
        free(people);
        return NULL;
    }

    return people;
}

bool CmpPassword(People *people, char *password)
{
    if (strcmp(people->password, password) == 0)
    {
        return true;
    }
    return false;
}

void SavePeople(People *people, FILE *file)
{
    int lenName = strlen(people->name) + 1;
    fwrite(&lenName, sizeof(int), 1, file);
    fwrite(people->name, sizeof(char), lenName, file);

    int lenPassword = strlen(people->password) + 1;
    fwrite(&lenPassword, sizeof(int), 1, file);
    fwrite(people->password, sizeof(char), lenPassword, file);

    fwrite(&people->saldo, sizeof(double), 1, file);

    fwrite(&people->history.quantity, sizeof(int), 1, file);
    fwrite(&people->history.capacity, sizeof(int), 1, file);

    for (int i = 0; i < people->history.quantity; i++)
    {
        int len = strlen(people->history.data[i]) + 1;
        fwrite(&len, sizeof(int), 1, file);
        fwrite(people->history.data[i], sizeof(char), len, file);
    }
}

People *LoadPeople(FILE *file)
{
    People *people = (People *)malloc(sizeof(People));

    int lenName;
    fread(&lenName, sizeof(int), 1, file);
    people->name = (char *)malloc(lenName);
    fread(people->name, sizeof(char), lenName, file);
    people->name[lenName - 1] = '\0';

    int lenPassword;
    fread(&lenPassword, sizeof(int), 1, file);
    people->password = (char *)malloc(lenPassword);
    fread(people->password, sizeof(char), lenPassword, file);
    people->password[lenPassword - 1] = '\0';

    fread(&people->saldo, sizeof(double), 1, file);

    fread(&people->history.quantity, sizeof(int), 1, file);
    fread(&people->history.capacity, sizeof(int), 1, file);

    people->history.data = (char **)malloc(sizeof(char *) * people->history.capacity);

    for (int i = 0; i < people->history.quantity; i++)
    {
        int len;
        fread(&len, sizeof(int), 1, file);

        people->history.data[i] = malloc(len);
        fread(people->history.data[i], sizeof(char), len, file);
    }

    return people;
}

void SaveHistory(People *people, char *type, double value)
{
    time_t now = time(NULL);
    struct tm *info = localtime(&now);

    char bufferTime[32];
    strftime(bufferTime, sizeof(bufferTime), "%d/%m/%Y - %H:%M:%S", info);

    if (people->history.quantity >= people->history.capacity)
    {
        people->history.capacity *= 2;
        people->history.data = (char **)realloc(people->history.data, sizeof(char *) * people->history.capacity);
    }

    char bufferMsgFinal[100];
    snprintf(bufferMsgFinal, sizeof(bufferMsgFinal), "%s R$%2.2f - %s", type, value, bufferTime);

    people->history.data[people->history.quantity++] = strdup(bufferMsgFinal);
}

void Depositar(People *people, double value)
{
    people->saldo += value;
    SaveHistory(people, "depositou", value);
}

void Sacar(People *people, double value)
{
    if (value > people->saldo)
    {
        return;
    }

    people->saldo -= value;
    SaveHistory(people, "sacou", value);
}

void FreePeople(People *people)
{
    if (people == NULL)
        return;

    if (people->name)
    {
        free((void *)people->name);
        people->name = NULL;
    }

    if (people->password)
    {
        free((void *)people->password);
        people->password = NULL;
    }

    if (people->history.data)
    {
        for (int i = 0; i < people->history.quantity; i++)
            free((void *)people->history.data[i]);

        free((void *)people->history.data);
        people->history.data = NULL;
    }

    free((void *)people);
    people = NULL;
}

#endif // PEOPLE_H