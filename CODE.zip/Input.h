#ifndef INPUT_H
#define INPUT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    char *buffer;
    int size;
} Buffer;

Buffer *CreateBuffer(int size)
{
    Buffer *buffer = (Buffer *)malloc(sizeof(Buffer));

    buffer->size = size + 1;
    buffer->buffer = (char *)malloc(buffer->size);

    return buffer;
}

void ClearBuffer(Buffer *buffer)
{
    memset(buffer->buffer, 0, buffer->size);
    *(buffer->buffer) = '\0';
}

void SaveBufferKey(Buffer *buffer)
{
    if (fgets(buffer->buffer, buffer->size, stdin) == NULL)
    {
        ClearBuffer(buffer);
        return;
    }

    size_t len = strlen(buffer->buffer);
    if (len > 0 && buffer->buffer[len - 1] == '\n')
        buffer->buffer[len - 1] = '\0';
}

char *GetToBuffer(Buffer *buffer)
{
    return strdup(buffer->buffer);
}

void FreeBuffer(Buffer *buffer)
{
    if (buffer == NULL)
        return;

    if (buffer->buffer)
        free((void *)buffer->buffer);
    free((void *)buffer);
    buffer = NULL;
}

#endif // INPUT_H