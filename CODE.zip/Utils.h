#ifndef UTILS_H
#define UTILS_H

#ifdef _WIN32
#include <windows.h>
#endif

#include <locale.h>

void ClearScreen()
{
#ifdef _WIN32
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

    CONSOLE_SCREEN_BUFFER_INFO csbi;
    GetConsoleScreenBufferInfo(h, &csbi);

    DWORD cellCount = csbi.dwSize.X * csbi.dwSize.Y;
    DWORD count;

    COORD home = {0, 0};

    FillConsoleOutputCharacter(h, ' ', cellCount, home, &count);
    FillConsoleOutputAttribute(h, csbi.wAttributes, cellCount, home, &count);

    SetConsoleCursorPosition(h, home);
#else
    printf(CLEAR_FULL);
#endif
}

double parseAmount(char *str)
{
    struct lconv *lc = localeconv();
    char sep = (lc && lc->decimal_point && lc->decimal_point[0]) ? lc->decimal_point[0] : '.';

    char *tmp = strdup(str);
    if (!tmp)
        return 0.0;

    if (sep == ',')
    {
        for (char *p = tmp; *p; ++p)
        {
            if (*p == '.')
                *p = ',';
        }
    }
    else
    {
        for (char *p = tmp; *p; ++p)
        {
            if (*p == ',')
                *p = '.';
        }
    }

    char *endptr;
    double val = strtod(tmp, &endptr);
    free((void *)tmp);
    return val;
}

#endif // UTILS_H