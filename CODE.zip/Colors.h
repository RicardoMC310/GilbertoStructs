#ifndef COLORS_H
#define COLORS_H

// reset
#define RESET "\033[0m"

// textos BRIGHT (cores vivas)
#define BLACK "\033[90m"
#define RED "\033[91m"
#define GREEN "\033[92m"
#define YELLOW "\033[93m"
#define BLUE "\033[94m"
#define MAGENTA "\033[95m"
#define CYAN "\033[96m"
#define WHITE "\033[97m"

// negrito
#define BOLD "\033[1m"

// fundos BRIGHT
#define BG_BLACK "\033[100m"
#define BG_RED "\033[101m"
#define BG_GREEN "\033[102m"
#define BG_YELLOW "\033[103m"
#define BG_BLUE "\033[104m"
#define BG_MAGENTA "\033[105m"
#define BG_CYAN "\033[106m"
#define BG_WHITE "\033[107m"

// limpar tela e cursor
#define CLEAR_FULL "\033[3J\033[2J\033[H"
#define GOTO_HOME "\033[H"

#endif
