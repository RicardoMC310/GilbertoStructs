#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <locale.h>

#ifdef _WIN32
#include <windows.h>
#endif

#include "Colors.h"
#include "Input.h"
#include "Peoples.h"
#include "Utils.h"
#include "People.h"

static People *userLogin = NULL;

void CriarConta(Peoples *peoples);
void Logar(Peoples *peoples);

void ImprimirMenu(void (*fn)());
void DisplayMenu();
void DisplayMenuLogin();
void Execute(bool *isRunning, int op, Peoples *peoples, void (*fn)(bool *, int, Peoples *));
void ExecuteOp(bool *isRunning, int op, Peoples *peoples);
void ExecuteOpLogin(bool *isRunning, int op, Peoples *peoples);
void ImprimirSaldo();
void ImprimirHistorico();
void DeletarConta(Peoples *peoples);

int main(void)
{
    ClearScreen();
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
    setlocale(LC_ALL, "Portuguese");

    Peoples peoples = LoadPeoples(".peoples-bin");

    bool isRunning = true;

    do
    {
        void (*impri)() = DisplayMenu;
        void (*exec)(bool *, int, Peoples *) = ExecuteOp;

        if (userLogin)
        {
            impri = DisplayMenuLogin;
            exec = ExecuteOpLogin;
        }

        ImprimirMenu(impri);
        printf(BLUE BOLD "digite sua opção: " RESET);
        Buffer *buffer = CreateBuffer(2);
        SaveBufferKey(buffer);

        int op = atoi(GetToBuffer(buffer));

        Execute(&isRunning, op, &peoples, exec);

        FreeBuffer(buffer);
        SavePeoples(&peoples, ".peoples-bin");
    } while (isRunning);

    SavePeoples(&peoples, ".peoples-bin");

    userLogin = NULL;
    FreePeoples(&peoples);
    return 0;
}

void CriarConta(Peoples *peoples)
{
    Buffer *buffer = CreateBuffer(256);

    ClearScreen();
    printf(GREEN "digite seu nome de usuário: " RESET);
    SaveBufferKey(buffer);

    char *name = GetToBuffer(buffer);

    ClearScreen();
    printf(GREEN "digite sua senha de usuário: " RESET);
    SaveBufferKey(buffer);

    char *password = GetToBuffer(buffer);

    RegisterPeople(peoples, name, password);

    if (FindPeopleIndexName(peoples, name) != -1)
    {
        printf(CYAN BOLD "Conta criada com sucesso!\n" RESET);
        printf("Pressione Enter para continuar...");
        getchar();
    }

    free((void *)name);
    free((void *)password);

    FreeBuffer(buffer);
}

void Logar(Peoples *peoples)
{
    Buffer *buffer = CreateBuffer(256);

    ClearScreen();
    printf(GREEN "digite o nome de usuário: " RESET);
    SaveBufferKey(buffer);

    char *name = GetToBuffer(buffer);

    People *people = GetPeopleByName(peoples, name);
    if (people == NULL)
    {
        printf(RED "Conta não encontrada!\n" RESET);
        printf("Pressione Enter para continuar...");
        getchar();
        return;
    }

    char *password = NULL;

    do
    {
        ClearScreen();
        printf(GREEN "digite sua senha: " RESET);
        SaveBufferKey(buffer);
        password = GetToBuffer(buffer);

        if (!CmpPassword(people, password))
        {
            printf(RED "Senha incorreta!\n" RESET);
            printf("Pressione Enter para continuar...");
            getchar();
        }
    } while (!CmpPassword(people, password));

    userLogin = people;

    printf(CYAN BOLD "Conta logada com sucesso!\n" RESET);
    printf("Pressione Enter para continuar...");
    getchar();

    free((void *)name);
    free((void *)password);

    FreeBuffer(buffer);
    ClearScreen();
}

void ImprimirMenu(void (*fn)())
{
    ClearScreen();
    fn();
}

void DisplayMenu()
{
    printf(CYAN BOLD "╔════════════════════════════════╗\n" RESET);
    printf(CYAN BOLD "║        MENU PRINCIPAL          ║\n" RESET);
    printf(CYAN BOLD "╠════════════════════════════════╣\n" RESET);

    printf(CYAN BOLD "║ " RESET GREEN "1" RESET " - Sair                       " CYAN BOLD "║\n" RESET);
    printf(CYAN BOLD "║ " RESET GREEN "2" RESET " - Criar conta                " CYAN BOLD "║\n" RESET);
    printf(CYAN BOLD "║ " RESET GREEN "3" RESET " - Entrar na conta            " CYAN BOLD "║\n" RESET);
    printf(CYAN BOLD "║ " RESET GREEN "4" RESET " - Deletar conta              " CYAN BOLD "║\n" RESET);

    printf(CYAN BOLD "╚════════════════════════════════╝\n" RESET);
}

void DisplayMenuLogin()
{
    printf(MAGENTA BOLD "╔════════════════════════════════╗\n" RESET);
    printf(MAGENTA BOLD "║        MENU DA CONTA           ║\n" RESET);
    printf(MAGENTA BOLD "╠════════════════════════════════╣\n" RESET);

    printf(MAGENTA BOLD "║ " RESET YELLOW "1" RESET " - Sair                      " MAGENTA BOLD " ║\n" RESET);
    printf(MAGENTA BOLD "║ " RESET YELLOW "2" RESET " - Sair da conta             " MAGENTA BOLD " ║\n" RESET);
    printf(MAGENTA BOLD "║ " RESET YELLOW "3" RESET " - Ver saldo                 " MAGENTA BOLD " ║\n" RESET);
    printf(MAGENTA BOLD "║ " RESET YELLOW "4" RESET " - Ver histórico             " MAGENTA BOLD " ║\n" RESET);
    printf(MAGENTA BOLD "║ " RESET YELLOW "5" RESET " - Depositar                 " MAGENTA BOLD " ║\n" RESET);
    printf(MAGENTA BOLD "║ " RESET YELLOW "6" RESET " - Sacar                     " MAGENTA BOLD " ║\n" RESET);

    printf(MAGENTA BOLD "╚════════════════════════════════╝\n" RESET);
}

void Execute(bool *isRunning, int op, Peoples *peoples, void (*fn)(bool *, int, Peoples *))
{
    fn(isRunning, op, peoples);
}

void ExecuteOp(bool *isRunning, int op, Peoples *peoples)
{
    switch (op)
    {
    case 1:
        *isRunning = false;
        break;
    case 2:
        CriarConta(peoples);
        break;
    case 3:
        Logar(peoples);
        break;
    case 4:
        DeletarConta(peoples);
        break;
    default:
        printf(RED BOLD "\nOpção Inválida\n\n" RESET);
        printf("Pressione Enter para continuar...");
        getchar();
        break;
    }
}

void ExecuteOpLogin(bool *isRunning, int op, Peoples *peoples)
{
    switch (op)
    {
    case 1:
        *isRunning = false;
        break;
    case 2:
        userLogin = NULL;
        break;
    case 3:
        ImprimirSaldo();
        break;
    case 4:
        ImprimirHistorico();
        break;
    case 5:
    {
        Buffer *buffer = CreateBuffer(64);
        ClearScreen();

        printf(GREEN "digite o valor do depósito: " RESET);
        SaveBufferKey(buffer);

        char *s = GetToBuffer(buffer);
        double val = parseAmount(s);
        Depositar(userLogin, val);
        free((void *)s);

        FreeBuffer(buffer);
        break;
    }
    case 6:
    {
        Buffer *buffer = CreateBuffer(64);

        ClearScreen();
        printf(GREEN "digite o valor que deseja sacar: " RESET);
        SaveBufferKey(buffer);

        char *s = GetToBuffer(buffer);
        double val = parseAmount(s);
        Sacar(userLogin, val);
        free((void *)s);

        FreeBuffer(buffer);
        break;
    }
    default:
        printf(RED BOLD "\nOpção Inválida\n\n" RESET);
        printf("Pressione Enter para continuar...");
        getchar();
        break;
    }
}

void ImprimirSaldo()
{
    ClearScreen();
    printf(GREEN "Saldo atual: " RESET YELLOW " R$%2.2f\n" RESET, userLogin->saldo);
    printf("Pressione Enter para continuar...");
    getchar();
}

void ImprimirHistorico()
{
    ClearScreen();
    if (userLogin->history.quantity == 0)
    {
        printf(GREEN BOLD "nenhuma transação feita.\n" RESET);
    }
    else
    {
        int i;
        for (i = 0; i < userLogin->history.quantity; i++)
        {
            printf(CYAN BOLD "%s\n" RESET, *(userLogin->history.data + i));
        }
    }

    printf("Pressione Enter para continuar...");
    getchar();
}

void DeletarConta(Peoples *peoples)
{
    Buffer *buffer = CreateBuffer(256);

    ClearScreen();
    printf(GREEN "digite o nome do usuário: " RESET);
    SaveBufferKey(buffer);

    char *name = GetToBuffer(buffer);
    People *people = GetPeopleByName(peoples, name);
    if (!people)
    {
        printf(RED "Conta não encontrada!\n" RESET);
        printf("Pressione Enter para continuar...");
        getchar();
        FreeBuffer(buffer);
        return;
    }

    ClearScreen();
    printf(GREEN "digite a senha de usuário: " RESET);
    SaveBufferKey(buffer);

    char *password = GetToBuffer(buffer);
    if (!CmpPassword(people, password))
    {
        printf(RED "Senha incorreta! Conta não foi deletada\n" RESET);
        printf("Pressione Enter para continuar...");
        getchar();
        FreeBuffer(buffer);
        return;
    }

    RemovePeople(peoples, name);

    printf(CYAN BOLD "Conta deletada com sucesso!\n" RESET);
    printf("Pressione Enter para continuar...");
    getchar();

    free((void *)name);
    free((void *)password);

    FreeBuffer(buffer);
}